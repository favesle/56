package com.example.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Student1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
setContentView(R.layout.Student1Activity)

        // Элементы интерфейса
        val idText = findViewById<TextView>(R.id.studentId)
        val lastName = findViewById<TextView>(R.id.lastname)
        val firstName = findViewById<TextView>(R.id.firstname)
        val middleName = findViewById<TextView>(R.id.middlename)
        val birth = findViewById<TextView>(R.id.birthdate)
        val group = findViewById<TextView>(R.id.group)
        val role = findViewById<TextView>(R.id.role)
        val createQR = findViewById<Button>(R.id.sozdayqr)

        // Данные студента
        idText.text = "P-23-12026"
        lastName.text = "Фамилия: Захарова"
        firstName.text = "Имя: Анастасия"
        middleName.text = "Отчество: Михайловна"
        birth.text = "Дата рождения: 09.01.2008"
        group.text = "Группа: 31-ИСИП"
        role.text = "Роль: Студент"

        // Кнопка создания QR-кода
        createQR.setOnClickListener {
            val data = """
                ID: ${idText.text}
                ${lastName.text}
                ${firstName.text}
                ${middleName.text}
                ${birth.text}
                ${group.text}
                ${role.text}
            """.trimIndent()

            val qr = generateQR(data)
            showQR(qr)
        }
    }


