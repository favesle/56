package com.example.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class StudentCardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student1)

        // Здесь ты позже вставишь загрузку из API
        loadMockData()
    }

    private fun loadMockData() {
        // Тут временные данные — заменишь на запрос к бэку позже
        studentId.text = "P-23-12026"
        lastname.text = "Фамилия: Захарова"
        firstname.text = "Имя: Анастасия"
        middlename.text = "Отчество: Михайловна"
        birthdate.text = "Дата рождения: 09.01.2008"
        group.text = "Группа: 31-ИСИП"
        role.text = "Роль: Студент"

        Glide.with(this)
            .load("https://i.imgur.com/Q6aZ4hD.jpeg") // поставь ссылку на фото
            .into(studentPhoto)
    }
}