package com.example.myapplication.QrActivity;

public class kt {
}
