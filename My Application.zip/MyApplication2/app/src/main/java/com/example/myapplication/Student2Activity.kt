package com.example.myapplication

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Student2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}

private fun generateQR(text: String): Bitmap {
    val writer = QRCodeWriter()
    val matrix = writer.encode(text, BarcodeFormat.QR_CODE, 600, 600)
    val bmp = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)

    for (x in 0 until 600)
        for (y in 0 until 600)
            bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)

    return bmp
}


private fun showQR(bitmap: qrImage) {
    val img = ImageView(this)
    img.setImageBitmap(bitmap)

    AlertDialog.Builder(this)
        .setTitle("QR-код студента")
        .setView(img)

}
